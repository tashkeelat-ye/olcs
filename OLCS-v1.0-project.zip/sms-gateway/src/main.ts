import express from 'express';
import { parseSms } from './sms-parser.js';

const app = express();
app.use(express.json());

const API_URL = process.env.OLCS_API_URL || 'http://localhost:3000';

app.post('/sms', async (req, res) => {
  try {
    const message = req.body.message;
    const parsed = parseSms(message);

    const response = await fetch(`${API_URL}/v1/sms/receive`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
    });

    const data = await response.json();

    res.json({ success: true, parsed, backend: data });
  } catch (error) {
    res.status(400).json({ success: false, error: String(error) });
  }
});

app.listen(4000, () => {
  console.log('OLCS SMS Gateway running on port 4000');
});
