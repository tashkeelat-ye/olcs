export function parseSms(message: string) {
  const parts = message.split('|');
  if (parts.shift() !== 'OL1') throw new Error('Invalid SMS');

  const result: Record<string, string> = {};
  for (const part of parts) {
    const separator = part.indexOf('=');
    if (separator === -1) continue;
    result[part.substring(0, separator)] = part.substring(separator + 1);
  }
  return result;
}
