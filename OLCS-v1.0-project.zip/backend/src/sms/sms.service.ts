import { Injectable } from '@nestjs/common';

@Injectable()
export class SmsService {
  parse(message: string) {
    const parts = message.split('|');
    if (parts[0] !== 'OL1') throw new Error('Invalid OLCS SMS');

    const result: Record<string, string> = {};
    for (const part of parts.slice(1)) {
      const index = part.indexOf('=');
      if (index === -1) continue;
      result[part.substring(0, index)] = part.substring(index + 1);
    }
    return result;
  }
}
