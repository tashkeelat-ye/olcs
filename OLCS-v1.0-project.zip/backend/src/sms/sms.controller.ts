import { Body, Controller, Post } from '@nestjs/common';
import { SmsService } from './sms.service';

@Controller('v1/sms')
export class SmsController {
  constructor(private readonly service: SmsService) {}

  @Post('receive')
  receive(@Body() body: { message: string }) {
    const data = this.service.parse(body.message);
    return { success: true, data };
  }
}
