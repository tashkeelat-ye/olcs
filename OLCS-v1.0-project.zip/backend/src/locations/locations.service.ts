import { Injectable, UnauthorizedException } from '@nestjs/common';
import { randomUUID } from 'crypto';
import { DevicesService } from '../devices/devices.service';

@Injectable()
export class LocationsService {
  private locations: any[] = [];

  constructor(private readonly devices: DevicesService) {}

  receiveBatch(apiKey: string, locations: any[]) {
    const device = this.devices.findByApiKey(apiKey);
    if (!device || !device.active) throw new UnauthorizedException('Invalid device');

    const accepted: string[] = [];
    const duplicates: string[] = [];

    for (const item of locations) {
      const eventId = item.eventId || randomUUID();
      const exists = this.locations.some(
        x => x.deviceId === device.id && x.id === eventId,
      );

      if (exists) {
        duplicates.push(eventId);
        continue;
      }

      const location = {
        id: eventId,
        deviceId: device.id,
        latitude: item.latitude,
        longitude: item.longitude,
        accuracy: item.accuracy,
        altitude: item.altitude,
        speed: item.speed,
        bearing: item.bearing,
        capturedAt: new Date(item.capturedAt),
        receivedAt: new Date(),
        transport: 'internet',
      };

      this.locations.push(location);
      this.devices.updateLocation(device.id, location);
      accepted.push(location.id);
    }

    return { accepted, duplicates, rejected: [] };
  }

  findAll() { return this.locations; }

  findDeviceLocations(deviceId: string) {
    return this.locations
      .filter(x => x.deviceId === deviceId)
      .sort((a, b) =>
        new Date(a.capturedAt).getTime() - new Date(b.capturedAt).getTime(),
      );
  }
}
