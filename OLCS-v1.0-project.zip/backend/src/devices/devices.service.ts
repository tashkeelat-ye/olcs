import { Injectable } from '@nestjs/common';
import { randomBytes } from 'crypto';

@Injectable()
export class DevicesService {
  private devices: any[] = [];

  create(name: string, phoneNumber?: string) {
    const id = `device_${randomBytes(8).toString('hex')}`;
    const apiKey = randomBytes(32).toString('hex');
    const smsSecret = randomBytes(32).toString('hex');

    const device = {
      id, name, phoneNumber, apiKey, smsSecret, active: true,
      lastLatitude: null, lastLongitude: null, lastAccuracy: null, lastSeenAt: null,
    };

    this.devices.push(device);
    return device;
  }

  findAll() { return this.devices; }

  findByApiKey(apiKey: string) {
    return this.devices.find(d => d.apiKey === apiKey);
  }

  updateLocation(deviceId: string, location: any) {
    const device = this.devices.find(d => d.id === deviceId);
    if (!device) return;

    device.lastLatitude = location.latitude;
    device.lastLongitude = location.longitude;
    device.lastAccuracy = location.accuracy;
    device.lastSeenAt = new Date();
  }
}
