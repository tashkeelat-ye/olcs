import { Body, Controller, Get, Post } from '@nestjs/common';
import { DevicesService } from './devices.service';

@Controller('v1/devices')
export class DevicesController {
  constructor(private readonly service: DevicesService) {}

  @Get()
  getAll() { return this.service.findAll(); }

  @Post()
  create(@Body() body: { name: string; phoneNumber?: string }) {
    return this.service.create(body.name, body.phoneNumber);
  }
}
