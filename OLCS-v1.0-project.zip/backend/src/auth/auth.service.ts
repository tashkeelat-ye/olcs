import { Injectable, UnauthorizedException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';

@Injectable()
export class AuthService {
  private users = [
    {
      id: 'admin',
      email: 'admin@olcs.local',
      passwordHash: bcrypt.hashSync('ChangeMe123!', 10),
      name: 'Administrator',
    },
  ];

  async login(email: string, password: string) {
    const user = this.users.find(item => item.email === email);
    if (!user) throw new UnauthorizedException('Invalid credentials');

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) throw new UnauthorizedException('Invalid credentials');

    const token = jwt.sign(
      { sub: user.id, email: user.email },
      process.env.JWT_SECRET || 'development-secret',
      { expiresIn: '7d' },
    );

    return {
      accessToken: token,
      user: { id: user.id, email: user.email, name: user.name },
    };
  }
}
