package com.olcs.agent.data

import androidx.room.*

@Dao
interface LocationDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(location: LocationEntity)

    @Query("SELECT * FROM location_events WHERE status = 'PENDING' ORDER BY capturedAt ASC LIMIT 100")
    suspend fun getPending(): List<LocationEntity>

    @Query("UPDATE location_events SET status = :status, attempts = attempts + 1, lastAttemptAt = :time, transport = :transport WHERE eventId = :eventId")
    suspend fun updateStatus(
        eventId: String,
        status: String,
        transport: String?,
        time: Long
    )
}
