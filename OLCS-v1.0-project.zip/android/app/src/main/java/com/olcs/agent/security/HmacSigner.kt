package com.olcs.agent.security

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object HmacSigner {
    fun sign(secret: String, payload: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(), "HmacSHA256"))
        return mac.doFinal(payload.toByteArray()).joinToString("") {
            "%02x".format(it)
        }
    }
}
