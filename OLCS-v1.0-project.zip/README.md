# OLCS — Offline Location Communication System

A production-oriented starter monorepo for an Android offline-first location agent, backend API, SMS gateway, and web dashboard.

## Components
- Android Agent: GPS/GNSS + Room + foreground location service + sync worker + SMS transport.
- Backend: NestJS-compatible TypeScript API.
- SMS Gateway: receives gateway-forwarded SMS payloads and forwards them to backend.
- Dashboard: React/Vite monitoring UI.
- PostgreSQL: database schema via Prisma.

## Important
This repository is a functional foundation, not a claim that every production/security/compliance feature is complete. Before deployment:
- change all secrets and demo credentials;
- use HTTPS;
- configure a real PostgreSQL instance;
- implement persistent backend authentication/device storage;
- configure a real SMS gateway device/provider;
- test Android background-location behavior on target devices;
- obtain all required user consent and comply with applicable laws and platform policies.

## Quick start
1. `cp .env.example .env`
2. `docker compose up --build`
3. Run dashboard with `cd dashboard && npm install && npm run dev`
4. Open the Android project in Android Studio and build/run it.
