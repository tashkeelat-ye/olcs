import { Device, Location } from './types';

const API = 'http://localhost:3000';

export async function getDevices(): Promise<Device[]> {
  const response = await fetch(`${API}/v1/devices`);
  return response.json();
}

export async function getLocations(): Promise<Location[]> {
  const response = await fetch(`${API}/v1/locations`);
  return response.json();
}
