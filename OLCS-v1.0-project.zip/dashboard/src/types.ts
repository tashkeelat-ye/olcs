export interface Device {
  id: string;
  name: string;
  phoneNumber?: string;
  active: boolean;
  lastLatitude?: number;
  lastLongitude?: number;
  lastAccuracy?: number;
  lastSeenAt?: string;
}

export interface Location {
  id: string;
  deviceId: string;
  latitude: number;
  longitude: number;
  accuracy?: number;
  altitude?: number;
  speed?: number;
  bearing?: number;
  capturedAt: string;
  receivedAt: string;
  transport?: string;
}
