import { useEffect, useState } from 'react';
import { getDevices, getLocations } from './api';
import { Device, Location } from './types';

export default function App() {
  const [devices, setDevices] = useState<Device[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);

  useEffect(() => {
    const load = async () => {
      try {
        const [d, l] = await Promise.all([getDevices(), getLocations()]);
        setDevices(d);
        setLocations(l);
      } catch (e) {
        console.error(e);
      }
    };

    load();
    const interval = setInterval(load, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <main>
      <header>
        <h1>OLCS</h1>
        <span>Offline Location Communication System</span>
      </header>

      <section className="stats">
        <div className="card"><strong>{devices.length}</strong><span>الأجهزة</span></div>
        <div className="card"><strong>{locations.length}</strong><span>المواقع</span></div>
      </section>

      <section>
        <h2>الأجهزة</h2>
        <div className="devices">
          {devices.map(device => (
            <article className="device" key={device.id}>
              <h3>{device.name}</h3>
              <p>ID: {device.id}</p>
              <p>الموقع: {device.lastLatitude ?? 'غير متوفر'}, {device.lastLongitude ?? 'غير متوفر'}</p>
              <p>الدقة: {device.lastAccuracy ?? '-'}m</p>
              <p>آخر اتصال: {device.lastSeenAt ?? 'لم يتصل'}</p>
            </article>
          ))}
        </div>
      </section>

      <section>
        <h2>آخر المواقع</h2>
        <div className="locations">
          {locations.slice(-20).reverse().map(location => (
            <article className="location" key={location.id}>
              <strong>{location.latitude}, {location.longitude}</strong>
              <span>الدقة: {location.accuracy ?? '-'}m</span>
              <span>النقل: {location.transport ?? '-'}</span>
              <span>{location.capturedAt}</span>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
